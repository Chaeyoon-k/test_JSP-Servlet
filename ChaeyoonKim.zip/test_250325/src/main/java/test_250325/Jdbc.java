package test_250325;

import java.sql.DriverManager;
import java.sql.SQLException;

public class Jdbc {
	
		public static void main(String[] args) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "scott", "tiger");
				//--getconnection으로 연결한다
				System.out.println("DB 연결 완료");
				
			} catch (ClassNotFoundException e) {
				System.out.println("jdbc 드라이버 로드 에러");
			}catch (SQLException e) {
				System.out.println("DB 연결 오류"); //쿼리자체 오류나면
				
		}
		}
	}

